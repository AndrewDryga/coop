package networkgateway

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"io"
	"log"
	"maps"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"path"
	"reflect"
	"regexp"
	"slices"
	"strings"
	"sync"
	"time"

	"github.com/AndrewDryga/coop/internal/egress"
	"github.com/AndrewDryga/coop/internal/networkview"
)

type NativeBrokerBinding struct {
	RunID, Provider, Account string
	Epoch                    uint64
}

// Credentials and private keys are guard-only, never controller or agent config.
type NativeAccessSnapshot struct {
	Binding    NativeBrokerBinding
	Revision   uint64
	Expires    time.Time
	Revoked    bool
	Credential string
}

type NativeBrokerRequestLine struct {
	CredentialFree       bool
	Method, Path, Query  string
	Header, HeaderPrefix string
	// Public native selector, not a capability or grant.
	ClientHeader, ClientPrefix, ClientMarker string
	Segment, Suffix                          string
	Queries                                  []NativeBrokerQuery
	// Adapter-declared account-discovery identity projection; never guest input.
	AccountResponse *NativeBrokerAccountResponse
}

// NativeBrokerAccountResponse declares literal object keys for the fixed
// selected-identity projection. Only the adapter supplies the document grammar.
type NativeBrokerAccountResponse struct {
	Header, CollectionKey, IDKey, LegacyObjectKey, LegacyIDKey, OrderingKey, DefaultIDKey string
}

func (shape NativeBrokerAccountResponse) valid() bool {
	for _, key := range []string{shape.CollectionKey, shape.IDKey, shape.LegacyObjectKey, shape.LegacyIDKey, shape.OrderingKey, shape.DefaultIDKey} {
		if key == "" || len(key) > 128 || strings.Trim(key, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-") != "" {
			return false
		}
	}
	return shape.Header != "" && shape.CollectionKey != shape.OrderingKey && shape.CollectionKey != shape.DefaultIDKey && shape.OrderingKey != shape.DefaultIDKey
}

type NativeBrokerQuery struct {
	Name     string
	Values   []string
	Optional bool
	MaxBytes int
}

func (line NativeBrokerRequestLine) matches(request *http.Request) bool {
	target := request.URL
	return target != nil && !target.IsAbs() && target.Host == "" && target.User == nil &&
		target.Fragment == "" && !target.ForceQuery && target.RawPath == "" &&
		request.Method == line.Method && line.matchesPath(target.Path) && line.matchesQuery(target.RawQuery)
}

func (line NativeBrokerRequestLine) matchesPath(value string) bool {
	if line.Segment == "" {
		return value == line.Path
	}
	if !strings.HasPrefix(value, line.Path) || !strings.HasSuffix(value, line.Suffix) {
		return false
	}
	segment := strings.TrimSuffix(strings.TrimPrefix(value, line.Path), line.Suffix)
	if segment == "" || len(segment) > 1024 {
		return false
	}
	switch line.Segment {
	case "uuid":
		return len(segment) == 36 && segment[8] == '-' && segment[13] == '-' && segment[18] == '-' && segment[23] == '-' &&
			strings.Trim(strings.ReplaceAll(segment, "-", ""), "0123456789abcdef") == "" && strings.Count(segment, "-") == 4
	case "token":
		return segment != "." && segment != ".." && strings.Trim(segment, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.") == ""
	case "segments":
		for _, part := range strings.Split(segment, "/") {
			if part == "" || part == "." || part == ".." || strings.Trim(part, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.~:") != "" {
				return false
			}
		}
		return true
	}
	return false
}

// nativeQueryBytes are the bytes a URL query may carry (RFC 3986, section 3.4).
const nativeQueryBytes = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~!$&'()*+,;=:@/?%"

func (line NativeBrokerRequestLine) matchesQuery(raw string) bool {
	if len(line.Queries) == 0 {
		return raw == line.Query
	}
	// The query goes upstream as sent, so it must hold only query bytes: ParseQuery read
	// "pageToken=x#&scope=GLOBAL&limit=200" as pageToken "x#", and a provider that stops at the
	// '#' saw pageToken=x with its own default scope and limit.
	values, err := url.ParseQuery(raw)
	if err != nil || len(raw) > 8192 || strings.Trim(raw, nativeQueryBytes) != "" {
		return false
	}
	for _, rule := range line.Queries {
		value, present := values[rule.Name]
		if !present {
			if rule.Optional {
				continue
			}
			return false
		}
		if len(value) != 1 || strings.ContainsAny(value[0], "\x00\r\n") ||
			!(slices.Contains(rule.Values, value[0]) || rule.MaxBytes > 0 && len(value[0]) <= rule.MaxBytes) {
			return false
		}
		delete(values, rule.Name)
	}
	return len(values) == 0
}

func (line NativeBrokerRequestLine) valid() bool {
	if line.Segment != "" && line.Segment != "uuid" && line.Segment != "token" && line.Segment != "segments" ||
		strings.ContainsAny(line.Suffix, "?#% \t\x00\r\n") || len(line.Queries) > 8 || len(line.Queries) > 0 && line.Query != "" {
		return false
	}
	names := map[string]bool{}
	for _, rule := range line.Queries {
		if rule.Name == "" || names[rule.Name] || strings.Trim(rule.Name, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_") != "" ||
			len(rule.Values) == 0 && rule.MaxBytes == 0 || rule.MaxBytes < 0 || rule.MaxBytes > 4096 {
			return false
		}
		names[rule.Name] = true
	}
	switch line.Method {
	case http.MethodGet, http.MethodHead, http.MethodPost, http.MethodPut, http.MethodPatch, http.MethodDelete, http.MethodOptions:
	default:
		return false
	}
	clean := path.Clean(line.Path)
	return strings.HasPrefix(line.Path, "/") && (clean == line.Path || clean+"/" == line.Path) &&
		!strings.ContainsAny(line.Path, "?#% \t\x00\r\n") && !strings.ContainsAny(line.Query, "# \t\x00\r\n") &&
		(line.CredentialFree && line.Header == "" && line.HeaderPrefix == "" && line.ClientHeader == "" && line.ClientPrefix == "" && line.ClientMarker == "" ||
			!line.CredentialFree && mcpSecretHeader(strings.ToLower(line.Header))) && len(line.HeaderPrefix) <= MaxMCPHeaderPrefix &&
		len(line.ClientPrefix) <= MaxMCPHeaderPrefix && len(line.ClientMarker) <= 32<<10 &&
		!strings.ContainsAny(line.HeaderPrefix+line.ClientPrefix+line.ClientMarker, "\x00\r\n") &&
		(line.ClientMarker == "" && line.ClientHeader == "" ||
			line.ClientMarker != "" && mcpSecretHeader(strings.ToLower(line.ClientHeader)))
}

type NativeBrokerOrigin struct {
	Host        string
	Certificate tls.Certificate
	Requests    []NativeBrokerRequestLine
	// Immutable selected-account facts, e.g. ChatGPT-Account-ID.
	AccountHeaders map[string]string
	// Public native account selector, distinct from real upstream identity.
	ClientAccountHeaders map[string]string
	// Existing filtered admission or open direct dial, never guest input.
	DialContext func(context.Context, string, string) (net.Conn, error)
}

type nativeBrokerRoute struct {
	line  NativeBrokerRequestLine
	proxy *httputil.ReverseProxy
}

type nativeBrokerOrigin struct {
	certificate          tls.Certificate
	clientAccountHeaders http.Header
	routes               []nativeBrokerRoute
	transport            *http.Transport
}

type NativeBroker struct {
	binding         NativeBrokerBinding
	load            func(context.Context) (NativeAccessSnapshot, error)
	fallback        http.Handler
	origins         map[string]nativeBrokerOrigin
	ctx             context.Context
	cancel          context.CancelFunc
	server          *http.Server
	input           *nativeBrokerListener
	conns, requests chan struct{}
	mu              sync.Mutex
	last            NativeAccessSnapshot
	stopped         bool
	stop            nativeBrokerStop
	active          map[*nativeBrokerConn]struct{}
	// events records each refusal with the run's other gateway refusals; nil in an open run.
	events  *GuardEvents
	once    sync.Once
	workers sync.WaitGroup
}

type nativeBrokerStop struct {
	reason                     string
	previousRevision, revision uint64
	attempts                   int
	elapsed                    time.Duration
}

type nativeAccessKey struct{}

// NewNativeBroker terminates only declared original native origins. It owns no
// TCP listener: the selected run namespace supplies the one outer entrance.
func NewNativeBroker(parent context.Context, binding NativeBrokerBinding, origins []NativeBrokerOrigin,
	load func(context.Context) (NativeAccessSnapshot, error), fallback http.Handler) (*NativeBroker, error) {
	if parent == nil || load == nil || fallback == nil || len(origins) == 0 || binding.RunID == "" ||
		binding.Provider == "" || binding.Account == "" || binding.Epoch == 0 {
		return nil, Failure("native_broker_configuration_invalid")
	}
	ctx, cancel := context.WithCancel(parent)
	b := &NativeBroker{binding: binding, load: load, fallback: fallback, origins: map[string]nativeBrokerOrigin{},
		ctx: ctx, cancel: cancel, input: &nativeBrokerListener{accepted: make(chan net.Conn, maxCredentialBrokerFlows),
			done: make(chan struct{}), ready: make(chan struct{})},
		conns: make(chan struct{}, maxCredentialBrokerFlows), requests: make(chan struct{}, maxCredentialBrokerFlows),
		active: map[*nativeBrokerConn]struct{}{}}
	fail := func() (*NativeBroker, error) {
		b.stopProtected("configuration_invalid", 0, 0, 0)
		return nil, Failure("native_broker_configuration_invalid")
	}
	for _, declared := range origins {
		host, err := egress.NormalizeDomain(declared.Host, false)
		if err != nil || host != declared.Host || declared.DialContext == nil || len(declared.Requests) == 0 ||
			len(declared.Certificate.Certificate) == 0 || declared.Certificate.PrivateKey == nil {
			return fail()
		}
		if _, duplicate := b.origins[host]; duplicate {
			return fail()
		}
		leaf, err := x509.ParseCertificate(declared.Certificate.Certificate[0])
		if err != nil || leaf.VerifyHostname(host) != nil {
			return fail()
		}
		accountHeaders := make(http.Header)
		for name, value := range declared.AccountHeaders {
			key, lower := http.CanonicalHeaderKey(name), strings.ToLower(name)
			if !mcpSecretHeader(lower) || value == "" || len(value) > 4096 || strings.ContainsAny(value, "\x00\r\n") ||
				lower == "authorization" || lower == "x-api-key" || lower == "x-goog-api-key" || accountHeaders.Get(key) != "" {
				return fail()
			}
			accountHeaders.Set(key, value)
		}
		dial := declared.DialContext
		transport := &http.Transport{Proxy: nil,
			DialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
				if address != net.JoinHostPort(host, "443") || network != "tcp" && network != "tcp4" && network != "tcp6" {
					return nil, Failure("native_broker_request_refused")
				}
				admission, done := context.WithTimeout(ctx, GuardAdmissionTimeout)
				defer done()
				return dial(admission, network, address)
			},
			TLSClientConfig:   &tls.Config{MinVersion: tls.VersionTLS12, ServerName: host},
			ForceAttemptHTTP2: true, DisableCompression: true, MaxConnsPerHost: maxCredentialBrokerFlows,
			MaxIdleConnsPerHost: maxCredentialBrokerFlows, MaxIdleConns: maxCredentialBrokerFlows,
			IdleConnTimeout: time.Minute, TLSHandshakeTimeout: credentialBrokerTimeout, MaxResponseHeaderBytes: 1 << 20}
		clientAccountHeaders := accountHeaders.Clone()
		for name, value := range declared.ClientAccountHeaders {
			if accountHeaders.Get(name) == "" || value == "" || len(value) > 4096 || strings.ContainsAny(value, "\x00\r\n") {
				return fail()
			}
			clientAccountHeaders.Set(name, value)
		}
		origin := nativeBrokerOrigin{certificate: declared.Certificate, clientAccountHeaders: clientAccountHeaders, transport: transport}
		b.origins[host] = origin // establish cleanup ownership before further validation
		for _, line := range declared.Requests {
			if !line.valid() || accountHeaders.Get(line.Header) != "" || line.ClientHeader != "" && accountHeaders.Get(line.ClientHeader) != "" {
				return fail()
			}
			if shape := line.AccountResponse; shape != nil && (!shape.valid() || line.CredentialFree || line.Method != http.MethodGet ||
				line.Query != "" || len(line.Queries) != 0 || line.Segment != "" || line.Suffix != "" || line.ClientMarker == "" ||
				accountHeaders.Get(shape.Header) == "" || clientAccountHeaders.Get(shape.Header) == "" ||
				accountHeaders.Get(shape.Header) == clientAccountHeaders.Get(shape.Header)) {
				return fail()
			}
			if line.AccountResponse != nil {
				shape := *line.AccountResponse
				line.AccountResponse = &shape // immutable transport-owned declaration
			}
			for _, prior := range origin.routes {
				if prior.line.Method == line.Method && prior.line.Path == line.Path && prior.line.Query == line.Query &&
					prior.line.Segment == line.Segment && prior.line.Suffix == line.Suffix && reflect.DeepEqual(prior.line.Queries, line.Queries) {
					return fail()
				}
			}
			proxy := &httputil.ReverseProxy{Transport: transport,
				Rewrite: func(p *httputil.ProxyRequest) {
					access := p.In.Context().Value(nativeAccessKey{}).(NativeAccessSnapshot)
					p.Out.URL.Scheme, p.Out.URL.Host, p.Out.Host = "https", host, host
					for _, header := range []string{"Authorization", "Proxy-Authorization", "Cookie", "X-Api-Key", "X-Goog-Api-Key", line.Header, line.ClientHeader} {
						if header != "" {
							p.Out.Header.Del(header)
						}
					}
					for name, values := range accountHeaders {
						p.Out.Header.Del(name)
						if !line.CredentialFree {
							p.Out.Header.Set(name, values[0])
						}
					}
					if !line.CredentialFree {
						p.Out.Header.Set(line.Header, line.HeaderPrefix+access.Credential)
					}
					if line.AccountResponse != nil {
						p.Out.Header.Set("Accept-Encoding", "identity")
						// A cached upstream body would still contain the private identity.
						p.Out.Header.Del("If-None-Match")
						p.Out.Header.Del("If-Modified-Since")
					}
				},
				ModifyResponse: func(response *http.Response) error {
					response.Header.Del("Set-Cookie")
					if response.StatusCode >= 300 && response.StatusCode < 400 && response.StatusCode != http.StatusNotModified {
						return Failure("native_broker_redirect_refused")
					}
					if shape := line.AccountResponse; shape != nil && response.StatusCode >= 200 && response.StatusCode < 400 {
						return projectNativeAccountResponse(response, *shape, accountHeaders.Get(shape.Header), clientAccountHeaders.Get(shape.Header))
					}
					return nil
				},
				ErrorHandler: func(w http.ResponseWriter, request *http.Request, _ error) {
					if request.Context().Err() == nil {
						http.Error(w, "native provider unavailable", http.StatusBadGateway)
					}
				}, FlushInterval: -1}
			origin.routes = append(origin.routes, nativeBrokerRoute{line: line, proxy: proxy})
		}
		b.origins[host] = origin
	}
	b.server = &http.Server{Handler: http.HandlerFunc(b.serveNative), BaseContext: func(net.Listener) context.Context { return b.ctx },
		TLSConfig:         &tls.Config{MinVersion: tls.VersionTLS12, NextProtos: []string{"h2", "http/1.1"}},
		ReadHeaderTimeout: 5 * time.Second, IdleTimeout: time.Minute, MaxHeaderBytes: 1 << 20}
	if _, err := b.current(); err != nil {
		return nil, err
	}
	b.workers.Add(2)
	go func() {
		defer b.workers.Done()
		_ = b.server.Serve(b.input)
		b.stopProtected("server_stopped", 0, 0, 0)
	}()
	go func() {
		defer b.workers.Done()
		ticker := time.NewTicker(100 * time.Millisecond)
		defer ticker.Stop()
		for {
			select {
			case <-b.ctx.Done():
				b.stopProtected("context_canceled", 0, 0, 0)
				return
			case <-ticker.C:
				// An unsettled read keeps polling: this tick is what latches a lease that lapses unread.
				if _, err := b.current(); err != nil && !errors.Is(err, errNativeAccessUnsettled) {
					return
				}
			}
		}
	}()
	select {
	case <-b.input.ready:
		return b, nil
	case <-b.ctx.Done():
		_ = b.Close()
		return nil, Failure("native_broker_unavailable")
	}
}

func nativeSnapshotFailure(binding NativeBrokerBinding, previous, next NativeAccessSnapshot, now time.Time) string {
	switch {
	case next.Binding != binding:
		return "binding_mismatch"
	case next.Revoked:
		return "revoked"
	case next.Revision == 0:
		return "revision_missing"
	case next.Revision < previous.Revision:
		return "revision_rollback"
	case !next.Expires.After(now):
		return "expired"
	case len(next.Credential) == 0 || len(next.Credential) > 32<<10 || strings.ContainsAny(next.Credential, "\x00\r\n"):
		return "credential_invalid"
	case next.Revision == previous.Revision && (next.Credential != previous.Credential || !next.Expires.Equal(previous.Expires)):
		return "revision_mutation"
	default:
		return ""
	}
}

// errNativeAccessUnsettled refuses one request while the access document could not be read in
// time. Unlike native_broker_revoked it does not stop the broker.
var errNativeAccessUnsettled = Failure("native_account_unavailable")

// nativeReadUnsettled reports a read that ended on its deadline rather than on what the document
// said. A loaded host's VM bind mount once took 1233 ms for one read (attempts=1, past the 1 s
// budget), and latching on that refused the agent's own provider for the rest of the run.
func nativeReadUnsettled(reason string) bool {
	switch reason {
	case "load_deadline", "document_canceled", "document_missing", "document_incomplete":
		return true
	}
	return false
}

func (b *NativeBroker) current() (NativeAccessSnapshot, error) {
	// Serialize reads and comparisons so completion order cannot look like rollback.
	b.mu.Lock()
	if b.stopped {
		b.mu.Unlock()
		return NativeAccessSnapshot{}, Failure("native_broker_revoked")
	}
	ctx, done := context.WithTimeout(b.ctx, time.Second)
	started := time.Now()
	next, err := b.load(ctx)
	loadErr := ctx.Err()
	done()
	reason, attempts := "", 0
	var documentErr *nativeDocumentFailure
	switch {
	case b.ctx.Err() != nil:
		reason = "context_canceled"
	case errors.As(err, &documentErr):
		reason, attempts = documentErr.reason, documentErr.attempts
	case loadErr != nil:
		reason = "load_deadline"
	case err != nil:
		reason = "load_failed"
	default:
		reason = nativeSnapshotFailure(b.binding, b.last, next, time.Now())
	}
	if reason == "" {
		b.last = next
	} else if nativeReadUnsettled(reason) && b.last.Expires.After(time.Now()) {
		// A read that ran out of time says nothing about the account: the host revokes by
		// publishing a revoked document, never by withholding one. Refuse this request, keep the
		// revision watermark so a rollback still latches, and let the next read decide. The last
		// lease bounds the wait: once it lapses unread, the failure below latches as before.
		b.mu.Unlock()
		return NativeAccessSnapshot{}, errNativeAccessUnsettled
	} else {
		b.latchProtected(reason, next.Revision, attempts, time.Since(started))
	}
	b.mu.Unlock()
	if reason != "" {
		b.finishProtected()
		return NativeAccessSnapshot{}, Failure("native_broker_revoked")
	}
	return next, nil
}

func (b *NativeBroker) ServeHTTP(w http.ResponseWriter, request *http.Request) {
	if request.Method != http.MethodConnect {
		b.fallback.ServeHTTP(w, request)
		return
	}
	host, port, err := net.SplitHostPort(request.Host)
	origin, protected := b.origins[host]
	if !protected {
		b.fallback.ServeHTTP(w, request)
		return
	}
	if err != nil || port != "443" || request.RequestURI != request.Host || request.URL.Host != request.Host ||
		request.ContentLength > 0 || len(request.TransferEncoding) != 0 || request.Header.Get("Proxy-Authorization") != "" {
		b.refuse(w, request, host, "native_broker_connect_refused", "native CONNECT refused")
		return
	}
	if _, err := b.current(); err != nil {
		b.refuse(w, request, host, safeReason(err), "native account unavailable")
		return
	}
	select {
	case b.conns <- struct{}{}:
	default:
		http.Error(w, "native provider busy", http.StatusServiceUnavailable)
		return
	}
	conn, buffered, err := http.NewResponseController(w).Hijack()
	if err != nil {
		<-b.conns
		http.Error(w, "native CONNECT unavailable", http.StatusInternalServerError)
		return
	}
	pending := make([]byte, buffered.Reader.Buffered())
	if _, err = io.ReadFull(buffered.Reader, pending); err != nil {
		_ = conn.Close()
		<-b.conns
		return
	}
	tracked := &nativeBrokerConn{Conn: conn}
	tracked.closed = func() { b.mu.Lock(); delete(b.active, tracked); b.mu.Unlock(); <-b.conns }
	b.mu.Lock()
	if b.stopped {
		b.mu.Unlock()
		_ = conn.Close()
		<-b.conns
		return
	}
	b.active[tracked] = struct{}{}
	b.mu.Unlock()
	fail := func() { _ = tracked.Close() }
	_ = conn.SetWriteDeadline(time.Now().Add(GuardAdmissionTimeout))
	if _, err := buffered.WriteString("HTTP/1.1 200 Connection Established\r\n\r\n"); err != nil {
		fail()
		return
	}
	if buffered.Flush() != nil {
		fail()
		return
	}
	_ = conn.SetWriteDeadline(time.Time{})
	secure := tls.Server(&prefixedConn{Conn: tracked, prefix: pending}, &tls.Config{
		MinVersion: tls.VersionTLS12, NextProtos: []string{"h2", "http/1.1"},
		GetCertificate: func(hello *tls.ClientHelloInfo) (*tls.Certificate, error) {
			if hello.ServerName != host {
				return nil, Failure("native_broker_tls_name_mismatch")
			}
			return &origin.certificate, nil
		},
	})
	handshake, done := context.WithTimeout(b.ctx, GuardAdmissionTimeout)
	err = secure.HandshakeContext(handshake)
	done()
	if err != nil {
		fail()
		return
	}
	select {
	case b.input.accepted <- secure:
	case <-b.ctx.Done():
		fail()
	}
}

func (b *NativeBroker) serveNative(w http.ResponseWriter, request *http.Request) {
	if request.TLS == nil {
		http.Error(w, "native TLS required", http.StatusForbidden)
		return
	}
	host := request.TLS.ServerName
	origin, ok := b.origins[host]
	if !ok || request.Host != host && request.Host != host+":443" {
		if !ok {
			host = "" // the handshake admits only declared names; never record another
		}
		b.refuse(w, request, host, "native_broker_origin_refused", "native origin refused")
		return
	}
	for name, expected := range origin.clientAccountHeaders {
		values := request.Header.Values(name)
		if len(values) != 0 && (len(values) != 1 || values[0] != expected[0]) {
			b.refuse(w, request, host, "native_broker_account_refused", "native account selector refused")
			return
		}
	}
	for _, route := range origin.routes {
		if !route.line.matches(request) {
			continue
		}
		if route.line.ClientMarker != "" {
			values := request.Header.Values(route.line.ClientHeader)
			if len(values) != 1 || values[0] != route.line.ClientPrefix+route.line.ClientMarker {
				b.refuse(w, request, host, "native_broker_account_refused", "native account selector refused")
				return
			}
		}
		select {
		case b.requests <- struct{}{}:
			defer func() { <-b.requests }()
		default:
			http.Error(w, "native provider busy", http.StatusServiceUnavailable)
			return
		}
		access, err := b.current()
		if err != nil {
			b.refuse(w, request, host, safeReason(err), "native account unavailable")
			return
		}
		request = request.WithContext(context.WithValue(request.Context(), nativeAccessKey{}, access))
		request.Body = http.MaxBytesReader(w, request.Body, maxCredentialBrokerBody)
		route.proxy.ServeHTTP(w, request)
		return
	}
	b.refuse(w, request, host, "native_broker_request_refused", "native route refused")
}

// refuse answers 403 and records the refusal beside the gateway's own, so a provider refused here
// shows in the run's evidence and `coop net blocked`, not only in the agent's log. Each check has its
// own reason, and the record names the request by its class (NativeRequestClass).
func (b *NativeBroker) refuse(w http.ResponseWriter, request *http.Request, host, reason, message string) {
	if b.events != nil {
		b.events.emit(GuardEvent{Kind: "admission_failed", Name: host, Reason: reason, Request: NativeRequestClass(request)})
	}
	http.Error(w, message, http.StatusForbidden)
}

// NativeRequestClass names a request the broker refused without anything it carried: the method,
// the path with every segment that is not a plain word shown as "*", and the names of its query
// parameters, never their values. An id, a token or a signed path cannot reach the record that way.
// A CONNECT is named by its method alone: its target is the destination the record already names.
func NativeRequestClass(request *http.Request) string {
	method := request.Method
	if len(method) > 16 || method == "" || strings.Trim(method, "ABCDEFGHIJKLMNOPQRSTUVWXYZ") != "" {
		method = "OTHER"
	}
	if method == http.MethodConnect || request.URL == nil {
		return method
	}
	segments := strings.Split(strings.TrimPrefix(request.URL.Path, "/"), "/")
	if len(segments) > 8 {
		segments = append(segments[:8], "…")
	}
	for i, segment := range segments {
		if segment != "…" && (len(segment) > 40 || !nativePathWord(segment)) {
			segments[i] = "*"
		}
	}
	class := method + " /" + strings.Join(segments, "/")
	if request.URL.RawQuery != "" {
		names := []string{"…"} // a query that does not parse is named by its presence alone
		if values, err := url.ParseQuery(request.URL.RawQuery); err == nil && len(values) != 0 {
			names = slices.Sorted(maps.Keys(values))
			for i, name := range names {
				if len(name) > 40 || !nativeQueryName(name) {
					names[i] = "*"
				}
			}
		}
		class += "?" + strings.Join(names, "&")
	}
	if len(class) > networkview.MaxRequestClass {
		class = strings.ToValidUTF8(class[:networkview.MaxRequestClass-len("…")], "") + "…"
	}
	return class
}

// nativePathWord matches a path segment that names an endpoint rather than a value: lowercase words
// joined by "-", "_" or ".", with an optional leading dot and at most two trailing digits ("v1",
// "wham", "rate-limit-reset-credits", ".well-known"). An id like "plugin_ab12c3" or a token is not one.
// An empty segment is a trailing or doubled slash, shown as it was sent.
var nativePathWord = regexp.MustCompile(`^(\.?[a-z]+([-_.][a-z]+)*[0-9]{0,2})?$`).MatchString

// nativeQueryName is the same for a query name, in either case ("pageToken", "client_version"). A
// query that is only a token ("?a3f9c2e1") parses as a name, and is not one.
var nativeQueryName = regexp.MustCompile(`^[A-Za-z]+([-_.][A-Za-z]+)*[0-9]{0,2}$`).MatchString

func (b *NativeBroker) stopProtected(reason string, revision uint64, attempts int, elapsed time.Duration) {
	b.mu.Lock()
	b.latchProtected(reason, revision, attempts, elapsed)
	b.mu.Unlock()
	b.finishProtected()
}

// The caller holds mu: the first denial closes admission and clears access
// before any queued reader can run, even when teardown or diagnostics are slow.
func (b *NativeBroker) latchProtected(reason string, revision uint64, attempts int, elapsed time.Duration) {
	if b.stopped {
		return
	}
	b.stopped = true
	b.stop = nativeBrokerStop{reason: reason, previousRevision: b.last.Revision, revision: revision, attempts: attempts, elapsed: elapsed}
	b.last = NativeAccessSnapshot{}
}

func (b *NativeBroker) finishProtected() {
	b.once.Do(func() {
		b.mu.Lock()
		stop := b.stop
		conns := make([]*nativeBrokerConn, 0, len(b.active))
		for conn := range b.active {
			conns = append(conns, conn)
		}
		b.mu.Unlock()
		b.cancel()
		if b.server != nil {
			_ = b.server.Close()
		}
		_ = b.input.Close()
		for _, conn := range conns {
			_ = conn.Close()
		}
		for _, origin := range b.origins {
			origin.transport.CloseIdleConnections()
		}
		// Shut protected traffic first: a blocked log sink must not delay
		// revocation. Never log raw errors, account identifiers or documents.
		log.Printf("native_broker_stopped reason=%s previous_revision=%d revision=%d attempts=%d load_ms=%d", stop.reason, stop.previousRevision, stop.revision, stop.attempts, stop.elapsed.Milliseconds())
	})
}

func (b *NativeBroker) Close() error {
	b.stopProtected("closed", 0, 0, 0)
	b.workers.Wait()
	return nil
}

type nativeBrokerConn struct {
	net.Conn
	once   sync.Once
	closed func()
}

func (c *nativeBrokerConn) Close() error { err := c.Conn.Close(); c.once.Do(c.closed); return err }

// This listener accepts already-connected TLS sockets; it never binds TCP.
type nativeBrokerListener struct {
	accepted        chan net.Conn
	done, ready     chan struct{}
	once, readyOnce sync.Once
}

func (l *nativeBrokerListener) Accept() (net.Conn, error) {
	l.readyOnce.Do(func() { close(l.ready) })
	select {
	case <-l.done:
		return nil, net.ErrClosed
	default:
	}
	select {
	case conn := <-l.accepted:
		return conn, nil
	case <-l.done:
		return nil, net.ErrClosed
	}
}

func (l *nativeBrokerListener) Close() error { l.once.Do(func() { close(l.done) }); return nil }
func (*nativeBrokerListener) Addr() net.Addr { return nativeBrokerAddr{} }

type nativeBrokerAddr struct{}

func (nativeBrokerAddr) Network() string { return "native" }
func (nativeBrokerAddr) String() string  { return "accepted-native-tls" }
