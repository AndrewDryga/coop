package networkgateway

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/netip"
	"net/url"
	"os"
	"os/exec"
	"path"
	"runtime"
	"slices"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/AndrewDryga/coop/internal/egress"
)

const (
	LaunchConfigPath     = "/run/coop-network.json"
	ControllerSocket     = "/ipc/controller/c.sock"
	EnvoyAdminSocket     = "/private/admin.sock"
	RuntimeSocket        = "/private/runtime.sock"
	EnvoyHealthTimeout   = 750 * time.Millisecond
	EnvoyStartTimeout    = 10 * time.Second
	EnvoyStopTimeout     = 2 * time.Second
	MaxLaunchConfigBytes = 4 << 20
	MaintenanceResolver  = "1.1.1.1"
	// MaintenanceResolverFallback is the same resolver's other address, dialed when a network
	// intercepts the first one (NewDoH). It has to prove the same name.
	MaintenanceResolverFallback = "1.0.0.1"
	MaintenanceResolverName     = "cloudflare-dns.com"
	CredentialBrokerPort        = 15580 // route 0's listener; route i listens on CredentialBrokerPort+i
	CredentialBrokerPath        = "/run/coop-credential-broker.json"
	// MaxCredentialBrokerRoutes bounds one run's brokered routes: a provider route per selected
	// account kind (at most 8) and a route per bearer-authenticated MCP server (at most 64).
	MaxCredentialBrokerRoutes = 72
)

// A brokered route is a provider's API, one secret-bearing MCP server, or a public download a
// client makes on its own and the agent's policy does not grant.
const (
	CredentialBrokerProvider = "provider"
	CredentialBrokerMCP      = "mcp"
	CredentialBrokerDownload = "download"
	// CredentialBrokerMCPSSE is the legacy SSE transport, which cannot take an exact route: the
	// server names its own message endpoint at runtime, on a path (and query) only that connection
	// knows. Its route admits GET on the stream's own path and POST anywhere on the SAME host, so
	// the credential still reaches one host and nothing else. Compatibility support, removable when
	// the server offers a streamable HTTP url.
	CredentialBrokerMCPSSE = "mcp-sse"
)

// MaxBrokerRequestLines bounds the request lines one download route forwards. Two is what a git
// fetch of one repository takes; the bound keeps a route from becoming a general proxy.
const MaxBrokerRequestLines = 4

// CredentialBrokerAddress is route i's listener on the gateway loopback the agent shares.
func CredentialBrokerAddress(route int) string {
	return net.JoinHostPort("127.0.0.1", strconv.Itoa(CredentialBrokerPort+route))
}

// CheckBrokerRoutes is the judgment the gateway makes of a run's routes, made HERE, where the plan
// is built: a route it would refuse fails the whole launch configuration with one opaque reason, so
// the host names the route instead.
func CheckBrokerRoutes(routes []CredentialBrokerRoute) error {
	for _, route := range routes {
		if !route.valid() {
			return fmt.Errorf("this run's network gateway refuses the broker route %q it was about to be given", route.Name)
		}
	}
	if !validBrokerRoutes(routes, nil, nil) {
		return errors.New("this run's network gateway refuses its set of broker routes")
	}
	return nil
}

// validBrokerRoutes holds each route to one exact provider endpoint, and keeps every route's
// listener off the ports the agent network contract serves or captures.
func validBrokerRoutes(routes []CredentialBrokerRoute, serve, tlsPorts []int) bool {
	if len(routes) > MaxCredentialBrokerRoutes {
		return false
	}
	for i, route := range routes {
		port := CredentialBrokerPort + i
		if !route.valid() || slices.Contains(serve, port) || slices.Contains(tlsPorts, port) {
			return false
		}
	}
	return true
}

// LaunchConfig contains a previously verified host capture, never an owner key,
// credential or agent-supplied executable/path. The direct read-only file mount
// and trusted image establish its provenance; the gateway cannot approve it.
type LaunchConfig struct {
	Version   int             `json:"version"`
	RunID     string          `json:"run_id"`
	Epoch     string          `json:"gateway_epoch"`
	AgentUID  uint32          `json:"agent_uid"`
	Policy    egress.Snapshot `json:"policy"`
	Protected []netip.Prefix  `json:"protected"`
	// Services binds each approved `service:` grant to the ONE container
	// address the host read from the runtime at launch. The box never resolves
	// a service name itself, so a sidecar that moves cannot widen the grant.
	Services []ServiceBinding `json:"services,omitempty"`
	// ServiceProxyClients are the exact named containers on Coop's internal
	// service network that may reach the guard's approved-TLS CONNECT endpoint.
	ServiceProxyClients []ServiceProxyClient `json:"service_proxy_clients,omitempty"`
	// Serve is this project's published container ports. They are ingress the
	// operator asked for, not egress authority.
	Serve []int `json:"serve,omitempty"`
	// Ingress is the bridge gateway address host-published traffic is NAT'd
	// from — the ONE source a served port accepts. Without it a sibling
	// container on the same bridge could reach a port the host published on
	// loopback only.
	Ingress netip.Addr `json:"ingress,omitempty"`
	// Brokers are non-secret helper-only authority derived from the selected adapters: one route per
	// brokered provider account, in listener order. The reusable credentials live in a separate
	// guard-only mount and never in this controller-readable file.
	Brokers       []CredentialBrokerRoute `json:"credential_brokers,omitempty"`
	NativeOrigins []string                `json:"native_origins,omitempty"`
}

// CredentialBrokerRoute is one exact endpoint a brokered credential reaches — a provider's API, or
// one bearer-authenticated MCP server — not a user policy or forward-proxy rule.
type CredentialBrokerRoute struct {
	Name         string   `json:"name"` // the provider, mcp-<i> for a tool server, or the download's own
	Kind         string   `json:"kind"`
	Upstream     string   `json:"upstream"`
	Header       string   `json:"header"`
	HeaderPrefix string   `json:"header_prefix,omitempty"`
	Methods      []string `json:"methods"`
	Path         string   `json:"path"`
	PathPrefix   bool     `json:"path_prefix,omitempty"`
	AllowQuery   bool     `json:"allow_query,omitempty"`
	Port         int      `json:"port"`
	// Allow is a download route's exact request lines. One listener carries a fetch's discovery
	// GET and its upload-pack POST, and nothing else: a third line would be a capability the
	// operator never granted, so the set is the route, not a prefix under it.
	Allow []BrokerRequestLine `json:"allow,omitempty"`
}

// BrokerRequestLine is one method and path a download route forwards, with the client's exact
// query where it sends one. The query is matched whole: git's discovery path serves a FETCH and a
// PUSH by query alone (`?service=git-upload-pack` vs `git-receive-pack`), so "any query" on that
// path would carry the first half of a push.
type BrokerRequestLine struct {
	Method string `json:"method"`
	Path   string `json:"path"`
	Query  string `json:"query,omitempty"`
}

func (r CredentialBrokerRoute) valid() bool {
	name, err := egress.NormalizeDomain(r.Upstream, false)
	if err != nil || name != r.Upstream || r.Name == "" || len(r.Name) > 32 ||
		strings.Trim(r.Name, "abcdefghijklmnopqrstuvwxyz0123456789-") != "" || r.Port != 443 {
		return false
	}
	if r.Kind == CredentialBrokerDownload {
		// A download carries NO credential: the fields that name one must be empty, or a route
		// meant to fetch public bytes could be given a secret to send with them.
		if r.Header != "" || r.HeaderPrefix != "" || len(r.Methods) != 0 || r.Path != "" || r.PathPrefix || r.AllowQuery ||
			len(r.Allow) == 0 || len(r.Allow) > MaxBrokerRequestLines {
			return false
		}
		for i, line := range r.Allow {
			if line.Method != http.MethodGet && line.Method != http.MethodPost || !validBrokerPath(line.Path) ||
				strings.ContainsAny(line.Query, "#\x00\r\n") ||
				slices.ContainsFunc(r.Allow[:i], func(seen BrokerRequestLine) bool { return seen == line }) {
				return false
			}
		}
		return true
	}
	if r.Header == "" || strings.ToLower(r.Header) != r.Header || !strings.HasPrefix(r.Path, "/") ||
		strings.ContainsAny(r.Path, "?#\x00\r\n") || strings.ContainsAny(r.HeaderPrefix, "\x00\r\n") {
		return false
	}
	switch r.Kind {
	case CredentialBrokerProvider:
		return slices.Equal(r.Methods, []string{"POST"})
	case CredentialBrokerMCPSSE:
		// The stream's own path, and the two methods the transport uses. Its breadth is in Admits,
		// not here: nothing about this route may be widened by configuration.
		return MCPSecretHeader(r.Header, r.HeaderPrefix) &&
			!r.PathPrefix && !r.AllowQuery && len(r.Allow) == 0 && slices.Equal(r.Methods, []string{"GET", "POST"})
	case CredentialBrokerMCP:
		// A streamable-HTTP endpoint: its exact path, the methods the protocol uses (POST a
		// message, GET the stream, DELETE the session), one secret header and no query.
		if len(r.Methods) == 0 || r.PathPrefix || r.AllowQuery || !MCPSecretHeader(r.Header, r.HeaderPrefix) {
			return false
		}
		for i, method := range r.Methods {
			if method != "GET" && method != "POST" && method != "DELETE" || slices.Contains(r.Methods[:i], method) {
				return false
			}
		}
		return true
	}
	return false
}

// MaxMCPHeaderPrefix bounds the literal text a secret header may carry before its credential.
const MaxMCPHeaderPrefix = 64

// MCPSecretHeader is the same judgment the gateway makes, for the host to make FIRST: a run that
// plans a header this gateway would reject refuses by server name while planning, instead of
// failing the whole launch configuration later with nothing a person could act on.
func MCPSecretHeader(name, prefix string) bool {
	return mcpSecretHeader(name) && len(prefix) <= MaxMCPHeaderPrefix && !strings.ContainsAny(prefix, "\x00\r\n")
}

// mcpSecretHeader reports whether an MCP server's secret may ride header name: a plain lower-case
// token that is none of the headers HTTP, the proxy or the MCP protocol itself owns — a secret
// there would break the transport or be rewritten on the way.
func mcpSecretHeader(name string) bool {
	if name == "" || len(name) > 64 || strings.Trim(name, "abcdefghijklmnopqrstuvwxyz0123456789-") != "" {
		return false
	}
	switch name {
	case "host", "connection", "keep-alive", "upgrade", "te", "trailer", "transfer-encoding",
		"cookie", "accept", "accept-encoding", "last-event-id",
		// Forwarding headers belong to the proxies on the path, which append to or rewrite them,
		// so a secret here would not reach the server as written.
		"x-forwarded-for", "forwarded":
		return false
	}
	return !strings.HasPrefix(name, "content-") && !strings.HasPrefix(name, "proxy-") && !strings.HasPrefix(name, "mcp-")
}

// validBrokerPath is one clean absolute path, with nothing a query or fragment would hide.
func validBrokerPath(value string) bool {
	return strings.HasPrefix(value, "/") && !strings.ContainsAny(value, "?#\x00\r\n") && path.Clean(value) == value
}

// Admits reports whether a request line fits the route's one endpoint: its method, its exact path
// (or one under it for a prefix route), and a query only where the adapter declared its client
// sends one. The path must already be in its one clean form: a dot segment, a doubled slash or a
// second encoding would let a prefix route name a sibling endpoint once the upstream normalizes
// it. Only an exact route's path may end in a slash (MCP endpoints like /mcp/ do) — it is then
// matched literally.
func (r CredentialBrokerRoute) Admits(method string, target *url.URL) bool {
	if clean := path.Clean(target.Path); clean != target.Path && (r.PathPrefix || clean+"/" != target.Path) ||
		target.RawPath != "" && target.RawPath != target.Path {
		return false
	}
	if r.Kind == CredentialBrokerDownload {
		return slices.ContainsFunc(r.Allow, func(line BrokerRequestLine) bool {
			return line.Method == method && line.Path == target.Path && line.Query == target.RawQuery && !target.IsAbs()
		})
	}
	if r.Kind == CredentialBrokerMCPSSE {
		// GET opens the one stream this route exists for; POST carries a message to the endpoint
		// that stream named, which only it knows — so any clean path on this host, with its query.
		// Nothing else: no DELETE, no second stream, and never another host.
		switch {
		case target.IsAbs():
			return false
		case method == http.MethodGet:
			return target.Path == r.Path && target.RawQuery == ""
		case method == http.MethodPost:
			return true
		}
		return false
	}
	pathMatches := target.Path == r.Path
	if r.PathPrefix {
		pathMatches = pathMatches || strings.HasPrefix(target.Path, strings.TrimSuffix(r.Path, "/")+"/")
	}
	return slices.Contains(r.Methods, method) && pathMatches && (r.AllowQuery || target.RawQuery == "") && !target.IsAbs()
}

type ServiceBinding struct {
	Name    string     `json:"name"`
	RuleID  string     `json:"rule_id"`
	Address netip.Addr `json:"address"`
}

type ServiceProxyClient struct {
	Name    string     `json:"name"`
	Address netip.Addr `json:"address"`
}

func ReadLaunchConfig(reader io.Reader) (LaunchConfig, error) {
	data, err := io.ReadAll(io.LimitReader(reader, MaxLaunchConfigBytes+1))
	if err != nil || len(data) > MaxLaunchConfigBytes {
		return LaunchConfig{}, Failure("gateway_configuration_invalid")
	}
	var value LaunchConfig
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if decoder.Decode(&value) != nil || decoder.Decode(new(any)) != io.EOF || value.Validate() != nil {
		return LaunchConfig{}, Failure("gateway_configuration_invalid")
	}
	return value, nil
}

func (c LaunchConfig) Validate() error {
	if len(c.NativeOrigins) > 8 || len(c.NativeOrigins) > 0 && slices.Contains(c.Serve, 15445) {
		return Failure("gateway_configuration_invalid")
	}
	for i, host := range c.NativeOrigins {
		name, err := egress.NormalizeDomain(host, false)
		if err != nil || name != host || slices.Contains(c.NativeOrigins[:i], host) {
			return Failure("gateway_configuration_invalid")
		}
	}
	if c.Version != 1 || !validAgentUID(c.AgentUID) || !lowerHex(c.RunID, 32) || !lowerHex(c.Epoch, 32) || !lowerHex(c.Policy.Fingerprint, 64) || c.Policy.Version != egress.Version ||
		len(c.Policy.Grants) > egress.MaxGrants || len(c.Protected) > MaxProtectedRanges || c.Policy.RequireSupported() != nil {
		return Failure("gateway_configuration_invalid")
	}
	for _, grant := range c.Policy.Grants {
		// The host authenticated this immutable capture. Reapplying today's
		// suffix catalog here would change authority across helper upgrades.
		rules, err := egress.CanonicalRules([]egress.Rule{grant.Rule})
		if err != nil || len(rules) != 1 || !lowerHex(grant.ID, 32) {
			return Failure("gateway_configuration_invalid")
		}
		original, _ := json.Marshal(grant.Rule)
		normalized, _ := json.Marshal(rules[0])
		if !bytes.Equal(original, normalized) {
			return Failure("gateway_configuration_invalid")
		}
	}
	for _, prefix := range c.Protected {
		if !prefix.IsValid() || prefix != prefix.Masked() || prefix.Addr().Is4In6() {
			return Failure("gateway_configuration_invalid")
		}
	}
	if len(c.Services) > egress.MaxGrants {
		return Failure("gateway_configuration_invalid")
	}
	for _, binding := range c.Services {
		if !lowerHex(binding.RuleID, 32) || binding.Name == "" || !binding.Address.Is4() {
			return Failure("gateway_configuration_invalid")
		}
	}
	if !validServiceProxyClients(c.Protected, c.ServiceProxyClients) || len(c.ServiceProxyClients) != 0 && slices.Contains(c.Serve, ServiceProxyPort) {
		return Failure("gateway_configuration_invalid")
	}
	if validServePorts(c.Serve, c.Policy.TLSPorts()) != nil {
		return Failure("gateway_configuration_invalid")
	}
	if len(c.Serve) != 0 && (!c.Ingress.Is4() || !c.Ingress.IsValid()) {
		return Failure("gateway_configuration_invalid")
	}
	if !validBrokerRoutes(c.Brokers, c.Serve, c.Policy.TLSPorts()) {
		return Failure("gateway_configuration_invalid")
	}
	// One construction, one meaning: the same grant/binding/port checks the
	// controller applies decide whether this configuration is launchable.
	if _, err := addressGrants(c.Policy, c.Services); err != nil {
		return Failure("gateway_configuration_invalid")
	}
	return nil
}

func (c LaunchConfig) identity(clock *BootClock) Identity {
	return Identity{Clock: clock.Domain(), RunID: c.RunID, Epoch: c.Epoch, PolicyFingerprint: c.Policy.Fingerprint}
}

func RunController(ctx context.Context, config LaunchConfig) error {
	if config.Validate() != nil || verifyServiceRole("controller") != nil {
		return Failure("gateway_configuration_invalid")
	}
	clock, err := OpenBootClock()
	if err != nil {
		return err
	}
	// A fresh volume/generation is mandatory. Never remove a stale socket and
	// accidentally bootstrap another controller beneath an existing workload.
	if err := os.Mkdir("/ipc/controller", 0710); err != nil {
		return Failure("controller_socket_unavailable")
	}
	c, err := NewController(config.identity(clock), config.AgentUID, config.Policy, config.Protected, config.Services, config.ServiceProxyClients,
		config.Serve, config.Ingress, config.Brokers, clock, applyKernelRules)
	if err != nil {
		return err
	}
	if err := c.Initialize(ctx, maintenanceResolvers()...); err != nil {
		return err
	}
	c.nativeOrigins = slices.Clone(config.NativeOrigins)
	c.kernel.read = readKernelCounters
	return c.ServeControl(ctx, ControllerSocket)
}

// maintenanceResolvers are the gateway resolver's addresses, in the order it dials them.
func maintenanceResolvers() []netip.Addr {
	return []netip.Addr{netip.MustParseAddr(MaintenanceResolver), netip.MustParseAddr(MaintenanceResolverFallback)}
}

func applyKernelRules(ctx context.Context, rules string) error {
	command := exec.CommandContext(ctx, "/usr/sbin/nft", "-f", "-")
	command.Stdin = strings.NewReader(rules)
	command.Stdout, command.Stderr = io.Discard, io.Discard
	command.Env = []string{"PATH=/usr/sbin:/usr/bin:/sbin:/bin", "LANG=C"}
	command.WaitDelay = time.Second
	if command.Run() != nil {
		return Failure("enforcement_unavailable")
	}
	return nil
}

// GuardRuntime owns one immutable gateway generation. Its sources are private
// in-process inputs to the observer; they confer no controller mutation API.
type GuardRuntime struct {
	Identity    Identity
	GuardEvents *GuardEvents
	EnvoyEvents *EnvoyEvents
	guard       *Guard
	brokers     []*credentialBroker
	native      *nativeRunRuntime
	doh         *DoH
	collector   *Collector
	started     atomic.Bool

	readiness        sync.Mutex
	phase            uint32
	proxyUnavailable bool
}

const (
	gatewayStarting uint32 = iota
	gatewayReady
	gatewayStopped
)

// markReady opens the gateway and has the collector say so at once: its latest sample predates
// readiness, and the next tick is up to a second away.
func (g *GuardRuntime) markReady() {
	g.readiness.Lock()
	changed := g.phase == gatewayStarting
	if changed {
		g.phase = gatewayReady
	}
	g.readiness.Unlock()
	if changed {
		g.collector.Wake()
	}
}

func (g *GuardRuntime) stopReady() {
	g.readiness.Lock()
	g.phase = gatewayStopped
	g.readiness.Unlock()
}

func (g *GuardRuntime) ready() bool {
	_, ready := g.probeStatus()
	return ready
}

func (g *GuardRuntime) probeStatus() (live, ready bool) {
	g.readiness.Lock()
	defer g.readiness.Unlock()
	live = g.phase == gatewayReady
	return live, live && !g.proxyUnavailable
}

func (g *GuardRuntime) setProxyReady(ready bool) {
	unavailable := !ready
	g.readiness.Lock()
	changed := g.proxyUnavailable != unavailable
	g.proxyUnavailable = unavailable
	g.readiness.Unlock()
	if changed {
		g.collector.Wake()
	}
}

func NewGuardRuntime(config LaunchConfig) (*GuardRuntime, error) {
	if config.Validate() != nil || verifyServiceRole("guard") != nil {
		return nil, Failure("gateway_configuration_invalid")
	}
	clock, err := OpenBootClock()
	if err != nil {
		return nil, err
	}
	var peers []netip.AddrPort
	for _, resolver := range maintenanceResolvers() {
		peers = append(peers, netip.AddrPortFrom(resolver, 443))
	}
	doh, err := NewDoH(peers, MaintenanceResolverName, nil, clock)
	if err != nil {
		return nil, err
	}
	r, err := NewResolver(config.Policy, config.Protected, config.Services, clock, doh.Exchange)
	if err != nil {
		doh.Close()
		return nil, err
	}
	events := NewGuardEvents(clock)
	identity := config.identity(clock)
	controller := ControllerClient{Path: ControllerSocket, Identity: identity, Clock: clock}
	guard, err := NewGuard(config.AgentUID, config.Policy, clock, r, controller, events)
	if err != nil {
		doh.Close()
		return nil, err
	}
	guard.serviceProxyClients = slices.Clone(config.ServiceProxyClients)
	envoyEvents := NewEnvoyEvents(clock)
	var brokers []*credentialBroker
	var brokerResolvers []*Resolver
	if len(config.Brokers) != 0 {
		file, openErr := os.Open(CredentialBrokerPath)
		if openErr != nil {
			doh.Close()
			return nil, Failure("credential_broker_configuration_invalid")
		}
		info, statErr := file.Stat()
		secrets, readErr := ReadCredentialBrokerSecrets(file, config)
		_ = file.Close()
		if statErr != nil || !info.Mode().IsRegular() || readErr != nil {
			doh.Close()
			return nil, Failure("credential_broker_configuration_invalid")
		}
		for route, secret := range secrets.Routes {
			broker, err := newCredentialBroker(config, route, secret, clock, doh, events, controller)
			if err != nil {
				doh.Close()
				return nil, err
			}
			brokers = append(brokers, broker)
			brokerResolvers = append(brokerResolvers, broker.resolver)
		}
	}
	runtime := &GuardRuntime{Identity: identity, GuardEvents: events, EnvoyEvents: envoyEvents, guard: guard, brokers: brokers, doh: doh}
	nativeResolvers, err := runtime.prepareNative(config, clock, controller)
	if err != nil {
		doh.Close()
		return nil, err
	}
	brokerResolvers = append(brokerResolvers, nativeResolvers...)
	collector, err := NewCollector(guard, envoyEvents, doh, brokerResolvers...)
	if err != nil {
		doh.Close()
		return nil, err
	}
	runtime.collector = collector
	return runtime, nil
}

func (g *GuardRuntime) Run(ctx context.Context) (result error) {
	if !g.started.CompareAndSwap(false, true) {
		return Failure("gateway_generation_used")
	}
	defer g.doh.Close()
	for _, path := range []string{EnvoyDataSocket, EnvoyAdminSocket, RuntimeSocket, RuntimeObserveSocket} {
		if _, err := os.Lstat(path); !os.IsNotExist(err) {
			return Failure("gateway_socket_occupied")
		}
	}
	if err := prepareObservationDirectory(ObservationDirectory); err != nil {
		return err
	}
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	observerCtx, stopObserver := context.WithCancel(context.WithoutCancel(ctx))
	var observers sync.WaitGroup
	observers.Go(func() { g.collector.Run(observerCtx, g.ready) })
	observers.Go(func() { _ = g.serveObservation(observerCtx, RuntimeObserveSocket, servicePeer) })
	defer func() {
		stopObserver()
		observers.Wait()
		// Registered before process/forwarder cleanup defers: these run first,
		// then this final sample consumes the already-drained terminal events.
		final, done := context.WithTimeout(context.Background(), ControlTimeout)
		defer done()
		if err := g.doh.Shutdown(final); err != nil {
			result = errors.Join(result, err)
		}
		g.collector.sample(final, false, true, g.guard.clock.instant())
		result = g.finishObservation(ObservationDirectory, result)
	}()
	// Linux parent-death signaling follows the creating OS thread, not the Go
	// goroutine. Keep that thread alive until its exact Envoy child is reaped.
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	command := exec.Command("/usr/local/bin/envoy", "--disable-hot-restart", "--concurrency", "1", "--log-level", "error",
		"--file-flush-interval-msec", "100", "--file-flush-min-size-kb", "1", "--config-yaml", EnvoyBootstrap)
	command.Env = []string{"PATH=/usr/local/bin:/usr/bin:/bin", "LANG=C"}
	command.SysProcAttr = envoyProcessAttributes()
	command.Stdout, command.Stderr = g.EnvoyEvents, io.Discard
	command.WaitDelay = time.Second
	if err := command.Start(); err != nil {
		g.EnvoyEvents.Finish(Failure("gateway_unavailable"))
		return Failure("gateway_unavailable")
	}
	processDone := make(chan struct{})
	go func() { g.EnvoyEvents.Finish(command.Wait()); close(processDone) }()
	defer func() {
		g.stopReady()
		cancel()
		select {
		case <-processDone:
			return
		default:
		}
		_ = command.Process.Signal(syscall.SIGTERM)
		timer := time.NewTimer(EnvoyStopTimeout)
		defer timer.Stop()
		select {
		case <-processDone:
		case <-timer.C:
			_ = command.Process.Kill()
			select {
			case <-processDone:
			case <-time.After(time.Second):
				result = errors.Join(result, Failure("gateway_shutdown_unconfirmed"))
			}
		}
	}()
	health := newEnvoyHealth(EnvoyAdminSocket, g.guard.clock)
	defer health.transport.CloseIdleConnections()
	startup, done := context.WithTimeout(ctx, EnvoyStartTimeout)
	defer done()
	for health.check(startup) != nil {
		select {
		case <-processDone:
			return envoyProcessExited
		case <-startup.Done():
			return Failure("gateway_start_timeout")
		case <-time.After(20 * time.Millisecond):
		}
	}
	var workers sync.WaitGroup
	defer func() { g.stopReady(); cancel(); workers.Wait() }()
	failures := make(chan error, 4+len(g.brokers))
	needed := int32(1 + len(g.brokers))
	if g.native != nil {
		needed++
	}
	var readyParts atomic.Int32
	partReady := func() {
		if readyParts.Add(1) == needed {
			g.markReady()
		}
	}
	workers.Go(func() { failures <- g.guard.Serve(ctx, partReady) })
	if g.native != nil {
		ordinary := newNativeOrdinaryProxy(ctx, g.guard)
		g.native.fallback = ordinary
		workers.Go(func() { defer ordinary.close(); failures <- g.native.serve(ctx, partReady) })
	}
	for _, broker := range g.brokers {
		workers.Go(func() { failures <- broker.Serve(ctx, partReady) })
	}
	workers.Go(func() { failures <- health.watch(ctx, g.setProxyReady) })
	workers.Go(func() { failures <- g.serveReadiness(ctx, RuntimeSocket, servicePeer) })
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-processDone:
		return envoyProcessExited
	case err := <-failures:
		return err
	}
}

const envoyAdminTimeoutLimit = 3

const (
	envoyAdminTimeout     Failure = "envoy_admin_timeout"
	envoyAdminNotReady    Failure = "envoy_admin_not_ready"
	envoyClockUnavailable Failure = "envoy_clock_unavailable"
	envoyProcessExited    Failure = "envoy_process_exited"
)

type envoyHealth struct {
	client    *http.Client
	transport *http.Transport
	clock     *BootClock
}

func newEnvoyHealth(path string, clock *BootClock) *envoyHealth {
	transport := &http.Transport{Proxy: nil, MaxConnsPerHost: 1, MaxIdleConns: 1, MaxIdleConnsPerHost: 1,
		MaxResponseHeaderBytes: 4096, ResponseHeaderTimeout: EnvoyHealthTimeout, DisableCompression: true,
		DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
			return (&net.Dialer{}).DialContext(ctx, "unix", path)
		}}
	return &envoyHealth{clock: clock, transport: transport, client: &http.Client{Transport: transport, Timeout: EnvoyHealthTimeout,
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}}
}

func (h *envoyHealth) check(ctx context.Context) error {
	started := h.clock.instant()
	if !started.Valid() {
		return envoyClockUnavailable
	}
	request, _ := http.NewRequestWithContext(ctx, http.MethodGet, "http://gateway/ready", nil)
	response, err := h.client.Do(request)
	if err != nil {
		return envoyAdminError(err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return envoyAdminNotReady
	}
	body, err := io.ReadAll(io.LimitReader(response.Body, 33))
	if err != nil {
		return envoyAdminError(err)
	}
	completed := h.clock.instant()
	if !completed.Valid() || completed.Before(started) {
		return envoyClockUnavailable
	}
	if string(body) != "LIVE\n" {
		return envoyAdminNotReady
	}
	if completed.Sub(started) > EnvoyHealthTimeout {
		return envoyAdminTimeout
	}
	return nil
}

func envoyAdminError(err error) Failure {
	var timeout net.Error
	if errors.As(err, &timeout) && timeout.Timeout() {
		return envoyAdminTimeout
	}
	return envoyAdminNotReady
}

func (h *envoyHealth) watch(ctx context.Context, setReady func(bool)) error {
	ticker := time.NewTicker(HeartbeatInterval)
	defer ticker.Stop()
	timeouts := 0
	for {
		err := h.check(ctx)
		if ctx.Err() != nil {
			return ctx.Err()
		}
		setReady(err == nil)
		switch err {
		case nil:
			timeouts = 0
		case envoyAdminTimeout:
			// An admin deadline can expire while the same process is still forwarding.
			// Only the readiness report changes until repeated misses justify teardown.
			timeouts++
			if timeouts >= envoyAdminTimeoutLimit {
				return err
			}
		default:
			return err
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
		}
	}
}

func (g *GuardRuntime) serveReadiness(ctx context.Context, path string, authenticate func(*net.UnixConn) bool) error {
	listener, err := net.ListenUnix("unix", &net.UnixAddr{Name: path, Net: "unix"})
	if err != nil {
		return Failure("gateway_socket_occupied")
	}
	defer listener.Close()
	if os.Chmod(path, 0600) != nil {
		return Failure("gateway_socket_occupied")
	}
	stop := context.AfterFunc(ctx, func() { _ = listener.Close() })
	defer stop()
	var workers sync.WaitGroup
	defer workers.Wait()
	slots := make(chan struct{}, 8)
	for {
		conn, err := listener.AcceptUnix()
		if err != nil {
			return Failure("gateway_unavailable")
		}
		select {
		case slots <- struct{}{}:
		default:
			_ = conn.Close()
			continue
		}
		workers.Go(func() {
			defer func() { <-slots; _ = conn.Close() }()
			if conn.SetDeadline(time.Now().Add(ControlTimeout)) != nil || !authenticate(conn) {
				return
			}
			var request controlRequest
			if readControl(conn, &request) != nil || request.Version != PrivateProtocolVersion || !request.Identity.matchesPeer(g.Identity) || request.Lease != nil || request.AfterBoot != 0 {
				return
			}
			live, ready := g.probeStatus()
			switch request.Operation {
			case "live":
				ready = live
			case "ready":
			default:
				return
			}
			_ = json.NewEncoder(conn).Encode(controlReply{Identity: g.Identity, Version: PrivateProtocolVersion, Ready: ready})
		})
	}
}

// ProbeRuntime is a host-exec readiness probe, not a guard heartbeat. It cannot
// keep a failed guard alive. The socket is absent from the agent's filesystem.
func ProbeRuntime(ctx context.Context, config LaunchConfig) error {
	return probeRuntime(ctx, config, "ready")
}

// ProbeRuntimeLiveness keeps the running watchdog independent of the guard's
// bounded proxy timeout recovery. It only succeeds while the guard is serving.
func ProbeRuntimeLiveness(ctx context.Context, config LaunchConfig) error {
	return probeRuntime(ctx, config, "live")
}

func probeRuntime(ctx context.Context, config LaunchConfig, operation string) error {
	if config.Validate() != nil || verifyServiceRole("guard") != nil {
		return Failure("gateway_configuration_invalid")
	}
	clock, err := OpenBootClock()
	if err != nil {
		return err
	}
	client := ControllerClient{Path: RuntimeSocket, Identity: config.identity(clock), Clock: clock}
	_, err = client.callPath(ctx, controlRequest{Version: PrivateProtocolVersion, Operation: operation}, RuntimeSocket)
	return err
}
