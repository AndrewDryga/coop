module github.com/AndrewDryga/coop

go 1.27

require (
	go.yaml.in/yaml/v3 v3.0.5
	golang.org/x/net v0.61.0
	golang.org/x/sys v0.49.0
)
